#!/bin/sh
echo [$0]: $1 ... > /dev/console
nvram set boot_wait=off
nvram commit
case "$1" in
start|stop|restart)
	service LAYOUT $1
	;;
*)
	echo [$0]: Invalid argument - $1 > /dev/console
	;;
esac

