#!/bin/sh
<?
function msg($m) {return 'echo "[INF-RESTART]: '.$m.'" > /dev/console';}
function say($m) {echo msg($m)."\n";}

if ($PREFIX!="")
{
	say("Stop [".$PREFIX."] services ...");
	echo "service ".$PREFIX." stop\n";
}
else
{
	say("Stop all INET services ...");
	echo "service WAN stop\n";
	echo "service LAN stop\n";
	echo "service BRIDGE stop\n";
}

foreach ("/runtime/inf")
{
	$uid = query("uid");
	if ($PREFIX!="" && cut($uid,0,'-')!=$PREFIX) continue;
	$mark = "/var/run/".$uid.".UP";
	$msg  = "Wait for ".$uid." to stop ...";
	//we just wait 5 seconds or whole system will be locked forever
	//After toggling ipv6 UI many times, INF-RESTART.php will be in the forever loop
	//For some reasons (we don't know why), /var/run/xxx.UP won't be removed. (tom, 20160311)
	echo 'timeout=0\nwhile [ -f '.$mark.' -a $timeout -lt 5 ]; do '.msg($msg).'; timeout=`expr $timeout + 1`; sleep 1; done\n';
	echo 'rm -f '.$mark.'\n';
}

if ($PREFIX!="")
{
	say("Start [".$PREFIX."] service ...");
	echo "service ".$PREFIX." start\n";
}
else
{
	say("Start all INET services");
	echo "service BRIDGE start\n";
	echo "service LAN start\n";
	echo "service WAN start\n";
}
?>
