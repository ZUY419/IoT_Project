#!/bin/sh

SLEEPTIME=15
while :
do
	sleep $SLEEPTIME
	status2g=`wl -i wifig0 bss`
	status5g=`wl -i wifia0 bss`
#   echo "Status: $status2g , $status5g"
	if [ "$status2g" == "down" ]&&[ "$status5g" == "down" ]; then
		echo "Not scan current ssid ,need to sitesurvey again!"
		service PHYINF.WIFI-REPEATER restart
	else
		echo "Uplink is connected!"
		exit 0
	fi
done
