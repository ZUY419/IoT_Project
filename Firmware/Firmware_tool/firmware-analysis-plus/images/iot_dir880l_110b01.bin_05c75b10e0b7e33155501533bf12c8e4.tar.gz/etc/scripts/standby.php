#!/bin/sh
echo $$ > /tmp/standby.pid
<?

function turn_off_wifi()
{
	echo "wl -i wifig0 down \n";
	echo "wl -i wifia0 down \n";
}

if($INF=="WAN")
{
	turn_off_wifi();
}
else if($INF=="LAN")
{
	turn_off_wifi();
}
else if($INF=="WLAN24G")
{
	turn_off_wifi();
	echo "wl -i wifig0 vhtmode 0 \n";
	echo "wl -i wifig0 bw_cap 2g 0x1 \n";
	echo "wl -i wifig0 chanspec 6 \n";
	echo "wl -i wifig0 up \n";
}
else if($INF=="WLAN5G")
{
	turn_off_wifi();
	echo "wl -i wifia0 vhtmode 0 \n";
	echo "wl -i wifia0 bw_cap 5g 0x1 \n";
	echo "wl -i wifia0 chanspec 36 \n";
	echo "wl -i wifia0 up \n";
}
?>
exit 0
